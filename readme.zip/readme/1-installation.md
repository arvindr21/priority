## Installation

```javascript
npm install [[ ids.npm ]] -D
```

If you don't want to install anything you can use the `npx [[ ids.npm ]] generate` command instead.